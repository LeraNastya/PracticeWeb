﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;

namespace WebAvia.Controllers
{
    [Authorize]
    public class RolesController : Controller
    {
        string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var roles = GetRoles();
            return View(roles);
        }

        public IActionResult Index1()
        {
            var roles = GetRoles();
            return View(roles);
        }

        private DataTable GetRoles()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Роли";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateRole(int id_роли, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Роли SET [{columnName}] = @newValue WHERE [Id роли] = @id_роли";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_роли", id_роли);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult DeleteRole(int id_роли)
        {
            try
            {
                string query = "DELETE FROM Роли WHERE [Id роли] = @id_роли";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_роли", id_роли);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult AddRole(string Название, string Описание)
        {
            try
            {
                string query = "INSERT INTO Роли (Название, Описание) VALUES (@Название, @Описание)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Название", Название);
                    command.Parameters.AddWithValue("@Описание", Описание);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }
    }
}
