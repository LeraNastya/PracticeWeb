﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using System.Data;
using System.Data.SqlClient;

namespace WebAvia.Controllers
{
    [Authorize]
    public class StatisticsController : Controller
    {
        private readonly string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            GetStatistics();
            return View();
        }

        private void GetStatistics()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string queryCompletedProjects = @"
                SELECT YEAR([Дата начала]) AS Year, COUNT(*) AS CompletedProjects
                FROM Проекты
                WHERE [Статус] = 1 AND [Дата начала] >= DATEADD(year, -5, GETDATE())
                GROUP BY YEAR([Дата начала])
                ORDER BY YEAR([Дата начала])";
                    DataTable completedProjectsTable = new DataTable();
                    new SqlDataAdapter(queryCompletedProjects, connection).Fill(completedProjectsTable);
                    ViewBag.CompletedProjects = completedProjectsTable;

                    string queryProjectsLast12Months = @"
                SELECT YEAR([Дата завершения]) AS Year, MONTH([Дата завершения]) AS Month, COUNT(*) AS ProjectsCount
                FROM Проекты
                WHERE [Статус] = 1 AND [Дата завершения] >= DATEADD(month, -11, GETDATE())
                GROUP BY YEAR([Дата завершения]), MONTH([Дата завершения])
                ORDER BY YEAR([Дата завершения]) DESC, MONTH([Дата завершения]) DESC";
                    DataTable projectsLast12MonthsTable = new DataTable();
                    new SqlDataAdapter(queryProjectsLast12Months, connection).Fill(projectsLast12MonthsTable);
                    ViewBag.ProjectsLast12Months = projectsLast12MonthsTable;

                    string queryBestEmployee = @"
                WITH TaskCounts AS (
                    SELECT s.[Id сотрудника], s.ФИО, COUNT(*) AS TaskCount
                    FROM Сотрудники s
                    JOIN Задачи z ON s.[Id сотрудника] = z.[Id сотрудника]
                    WHERE z.[Статус] = 1
                      AND CONVERT(datetime, z.[Срок выполнения], 104) >= DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0)
                    GROUP BY s.[Id сотрудника], s.ФИО
                ),
                MaxTaskCount AS (
                    SELECT MAX(TaskCount) AS MaxCount
                    FROM TaskCounts
                )
                SELECT tc.ФИО
                FROM TaskCounts tc
                JOIN MaxTaskCount mtc ON tc.TaskCount = mtc.MaxCount
                ORDER BY tc.ФИО";
                    DataTable bestEmployeesTable = new DataTable();
                    new SqlDataAdapter(queryBestEmployee, connection).Fill(bestEmployeesTable);
                    ViewBag.BestEmployeesOfTheMonth = bestEmployeesTable;
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
            }
        }

        public IActionResult GeneratePdf()
        {
            try
            {
                DataTable completedProjectsTable = new DataTable();
                DataTable projectsLast12MonthsTable = new DataTable();
                DataTable bestEmployeesTable = new DataTable();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string queryCompletedProjects = @"
        SELECT YEAR([Дата начала]) AS Year, COUNT(*) AS CompletedProjects
        FROM Проекты
        WHERE [Статус] = 1 AND [Дата начала] >= DATEADD(year, -5, GETDATE())
        GROUP BY YEAR([Дата начала])
        ORDER BY YEAR([Дата начала])";
                    new SqlDataAdapter(queryCompletedProjects, connection).Fill(completedProjectsTable);

                    string queryProjectsLast12Months = @"
        SELECT YEAR([Дата завершения]) AS Year, MONTH([Дата завершения]) AS Month, COUNT(*) AS ProjectsCount
        FROM Проекты
        WHERE [Статус] = 1 AND [Дата завершения] >= DATEADD(month, -11, GETDATE())
        GROUP BY YEAR([Дата завершения]), MONTH([Дата завершения])
        ORDER BY YEAR([Дата завершения]) DESC, MONTH([Дата завершения]) DESC";
                    new SqlDataAdapter(queryProjectsLast12Months, connection).Fill(projectsLast12MonthsTable);

                    string queryBestEmployee = @"
        WITH TaskCounts AS (
            SELECT s.[Id сотрудника], s.ФИО, COUNT(*) AS TaskCount
            FROM Сотрудники s
            JOIN Задачи z ON s.[Id сотрудника] = z.[Id сотрудника]
            WHERE z.[Статус] = 1
              AND CONVERT(datetime, z.[Срок выполнения], 104) >= DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0)
            GROUP BY s.[Id сотрудника], s.ФИО
        ),
        MaxTaskCount AS (
            SELECT MAX(TaskCount) AS MaxCount
            FROM TaskCounts
        )
        SELECT tc.ФИО
        FROM TaskCounts tc
        JOIN MaxTaskCount mtc ON tc.TaskCount = mtc.MaxCount
        ORDER BY tc.ФИО";
                    new SqlDataAdapter(queryBestEmployee, connection).Fill(bestEmployeesTable);
                }

                var document = Document.Create(container =>
                {
                    container.Page(page =>
                    {
                        page.Size(PageSizes.A4);
                        page.Margin(2, Unit.Centimetre);
                        page.Header()
                            .AlignCenter()
                            .Text(t => t.Span("Statistics Report").FontSize(20).SemiBold());

                        page.Content()
                            .PaddingVertical(1, Unit.Centimetre)
                            .Column(column =>
                            {
                                column.Item().Text(t => t.Span("Completed Projects:").Bold());
                                column.Item().PaddingBottom(1, Unit.Centimetre);

                                if (completedProjectsTable != null && completedProjectsTable.Rows.Count > 0)
                                {
                                    column.Item().Table(table =>
                                    {
                                        table.ColumnsDefinition(columns =>
                                        {
                                            columns.ConstantColumn(100);
                                            columns.RelativeColumn();
                                        });

                                        table.Header(header =>
                                        {
                                            header.Cell().Text("Year");
                                            header.Cell().Text("Completed Projects");
                                        });

                                        foreach (DataRow row in completedProjectsTable.Rows)
                                        {
                                            table.Cell().Text(row["Year"].ToString());
                                            table.Cell().Text(row["CompletedProjects"].ToString());
                                        }
                                    });
                                }
                                else
                                {
                                    column.Item().Text("No data available for Completed Projects.");
                                }

                                column.Item().PaddingVertical(1, Unit.Centimetre);

                                column.Item().Text(t => t.Span("Projects Last 12 Months:").Bold());
                                column.Item().PaddingBottom(1, Unit.Centimetre);

                                if (projectsLast12MonthsTable != null && projectsLast12MonthsTable.Rows.Count > 0)
                                {
                                    column.Item().Table(table =>
                                    {
                                        table.ColumnsDefinition(columns =>
                                        {
                                            columns.ConstantColumn(100);
                                            columns.RelativeColumn();
                                            columns.RelativeColumn();
                                        });

                                        table.Header(header =>
                                        {
                                            header.Cell().Text("Year");
                                            header.Cell().Text("Month");
                                            header.Cell().Text("Projects Count");
                                        });

                                        foreach (DataRow row in projectsLast12MonthsTable.Rows)
                                        {
                                            table.Cell().Text(row["Year"].ToString());
                                            table.Cell().Text(row["Month"].ToString());
                                            table.Cell().Text(row["ProjectsCount"].ToString());
                                        }
                                    });
                                }
                                else
                                {
                                    column.Item().Text("No data available for Projects Last 12 Months.");
                                }

                                column.Item().PaddingVertical(1, Unit.Centimetre);

                                column.Item().Text(t => t.Span("Best Employees of the Month:").Bold());
                                column.Item().PaddingBottom(1, Unit.Centimetre);

                                if (bestEmployeesTable != null && bestEmployeesTable.Rows.Count > 0)
                                {
                                    foreach (DataRow row in bestEmployeesTable.Rows)
                                    {
                                        column.Item().Text(row["ФИО"].ToString());
                                    }
                                }
                                else
                                {
                                    column.Item().Text("No data available for Best Employees of the Month.");
                                }
                            });

                        page.Footer()
                            .AlignCenter()
                            .Text(t =>
                            {
                                t.Span("Page ");
                                t.CurrentPageNumber();
                            });
                    });
                });

                var pdfBytes = document.GeneratePdf();
                return File(pdfBytes, "application/pdf", "StatisticsReport.pdf");
            }
            catch (Exception ex)
            {
                // Логирование ошибки или возврат ошибки пользователю
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
