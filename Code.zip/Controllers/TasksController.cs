﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using MailKit;
using MimeKit;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Authorization;

namespace WebAvia.Controllers
{
    [Authorize]
    public class TasksController : Controller
    {
        string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var tasks = GetTasks();
            return View(tasks);
        }

        public IActionResult Index1()
        {
            string login = HttpContext.Session.GetString("Login");
            var tasks = GetTasksForEmployee(login);

            // Формируем строку с информацией о проектах, которые были удалены из уведомлений
            string updatedTaksMessage = CheckAndRemoveTaskNotification(tasks);

            // Передаем строку с информацией о проектах в TempData
            TempData["UpdatedTasksMessage"] = updatedTaksMessage;

            return View(tasks);
        }

        public IActionResult IndexForTeamLead()
        {
            string login = HttpContext.Session.GetString("Login");
            var tasks = GetTasksForTeamLead(login);
            ViewBag.TeamLeadId = login; // Передаем teamLeadId в представление
            return View("Index", tasks);
        }

        private string CheckAndRemoveTaskNotification(DataTable projects)
        {
            string updatedTasksMessage = "";
            string query = @"
SELECT [Id задачи] FROM [Уведомления по задачам]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Получаем список проектов из таблицы Уведомления по проектам
                SqlCommand selectCommand = new SqlCommand(query, connection);
                SqlDataReader reader = selectCommand.ExecuteReader();
                var notificationT = new List<int>();

                while (reader.Read())
                {
                    notificationT.Add(reader.GetInt32(0));
                }

                reader.Close();

                // Проверяем каждый проект из таблицы проектов
                foreach (DataRow task in projects.Rows)
                {
                    int tId = (int)task["Id задачи"];
                    if (notificationT.Contains(tId))
                    {
                        // Удаляем уведомление
                        SqlCommand deleteCommand = new SqlCommand("DELETE FROM [Уведомления по задачам] WHERE [Id задачи] = @projectId", connection);
                        deleteCommand.Parameters.AddWithValue("@projectId", tId);
                        deleteCommand.ExecuteNonQuery();

                        // Добавляем информацию о проекте в строку
                        updatedTasksMessage = updatedTasksMessage + task["Id задачи"].ToString() + ", ";
                    }
                }

                if (!string.IsNullOrEmpty(updatedTasksMessage))
                {
                    updatedTasksMessage = updatedTasksMessage.TrimEnd(',', ' ');
                    updatedTasksMessage = updatedTasksMessage + ".";
                }
            }

            return updatedTasksMessage;
        }

        private DataTable GetTasksForEmployee(string employeeId)
        {
            DataTable table = new DataTable();
            try
            {
                if (string.IsNullOrEmpty(employeeId))
                {
                    TempData["ErrorMessage"] = "Ошибка: Идентификатор сотрудника не указан.";
                    return table;
                }

                string query = @"
    SELECT t.[Id задачи], t.[Название], t.[Описание],
           p.[Название] AS [Название проекта],
           e.[ФИО] AS [Сотрудник],
           t.[Срок выполнения], t.[Статус]
    FROM Задачи t
    JOIN Сотрудники e ON t.[Id сотрудника] = e.[Id сотрудника]
    JOIN Проекты p ON t.[Id проекта] = p.[Id проекта]
    WHERE t.[Id сотрудника] = @EmployeeId";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.SelectCommand.Parameters.AddWithValue("@EmployeeId", employeeId);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        private DataTable GetTasksForTeamLead(string teamLeadId)
        {
            DataTable table = new DataTable();
            try
            {
                string query = @"
            SELECT DISTINCT t.[Id задачи], t.[Название], t.[Описание],
                   t.[Id проекта],
                   t.[Срок выполнения], t.[Статус],
                   e.[ФИО] AS [Сотрудник], t.[Id сотрудника]
            FROM Задачи t
            JOIN Проекты p ON t.[Id проекта] = p.[Id проекта]
            JOIN Сотрудники e ON t.[Id сотрудника] = e.[Id сотрудника]
            WHERE p.[Id тим лида] = @TeamLeadId";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.SelectCommand.Parameters.AddWithValue("@TeamLeadId", teamLeadId);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        private DataTable GetTasks()
        {
            DataTable table = new DataTable();
            try
            {
                string query = @"
            SELECT t.[Id задачи], t.[Название], t.[Описание],
                   t.[Id проекта],
                   t.[Срок выполнения], t.[Статус],
                   e.[ФИО] AS [Сотрудник], t.[Id сотрудника]
            FROM Задачи t
            JOIN Сотрудники e ON t.[Id сотрудника] = e.[Id сотрудника]";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateTask(int id_задачи, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Задачи SET [{columnName}] = @newValue WHERE [Id задачи] = @id_задачи";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_задачи", id_задачи);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

                // Отправка уведомления, если изменяется сотрудник
                if (columnName.Equals("Id сотрудника", StringComparison.OrdinalIgnoreCase))
                {
                    int newEmployeeId = int.Parse(newValue);
                    SendEmailNotification(newEmployeeId, "Изменение задачи", $"Вам переведена задача с ID {id_задачи}.");

                    // Добавление ID проекта в таблицу Уведомления по проектам
                    AddTaskNotification(id_задачи);
                }

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult DeleteTask(int id_задачи)
        {
            try
            {
                string query = "DELETE FROM Задачи WHERE [Id задачи] = @id_задачи";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_задачи", id_задачи);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

                DeleteTaskNotification(id_задачи);

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        [HttpPost]
        public IActionResult AddTask(string Название, int id_проекта, int id_сотрудника)
        {
            try
            {
                int taskId = 0;
                string query = @"
            INSERT INTO Задачи (Название, [Id проекта], [Id сотрудника])
            VALUES (@Название, @id_проекта, @id_сотрудника);
            SET @TaskId = SCOPE_IDENTITY();";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Название", Название);
                    command.Parameters.AddWithValue("@id_проекта", id_проекта);
                    command.Parameters.AddWithValue("@id_сотрудника", id_сотрудника);

                    // Добавление выходного параметра
                    SqlParameter outputParam = new SqlParameter("@TaskId", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(outputParam);

                    connection.Open();
                    command.ExecuteNonQuery();

                    // Получение значения выходного параметра
                    taskId = (int)outputParam.Value;
                }

                // Отправка уведомления сотруднику
                SendEmailNotification(id_сотрудника, "Новая задача", $"Вам назначена новая задача с ID: {taskId}.");

                // Добавление ID проекта в таблицу Уведомления по проектам
                AddTaskNotification(taskId);

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }


        public JsonResult GetEmployees()
        {
            var employees = new List<object>();
            string query = "SELECT [Id сотрудника], [ФИО] FROM Сотрудники WHERE [Id роли]=3";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        employees.Add(new { Id = reader["Id сотрудника"], Name = reader["ФИО"] });
                    }
                }
            }

            return Json(employees);
        }

        public JsonResult GetProjectsForTeamLead(string teamLeadId)
        {
            var projects = new List<object>();
            string query = @"
                SELECT [Id проекта], [Название]
                FROM Проекты
                WHERE [Id тим лида] = @TeamLeadId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TeamLeadId", teamLeadId);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        projects.Add(new { Id = reader["Id проекта"], Name = reader["Название"] });
                    }
                }
            }

            return Json(projects);
        }

        public JsonResult GetAllProjects()
        {
            var projects = new List<object>();
            string query = "SELECT [Id проекта], [Название] FROM Проекты";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        projects.Add(new { Id = reader["Id проекта"], Name = reader["Название"] });
                    }
                }
            }

            return Json(projects);
        }

        private string GetEmployeeEmail(int employeeId)
        {
            string email = string.Empty;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Email FROM Сотрудники WHERE [Id сотрудника] = @EmployeeId";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmployeeId", employeeId);
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            email = reader["Email"].ToString();
                        }
                    }
                }
            }

            return email;
        }

        private void SendEmailNotification(int employeeId, string subject, string body)
        {
            string recipientEmail = GetEmployeeEmail(employeeId);

            var message = new MimeMessage();
            message.From.Add(new MailboxAddress("Валерия", "valerytihonova@mail.ru"));
            message.To.Add(new MailboxAddress("", recipientEmail));
            message.Subject = subject;
            message.Body = new TextPart("plain") { Text = body };

            using (var client = new MailKit.Net.Smtp.SmtpClient(new ProtocolLogger("smtp.log")))
            {
                try
                {
                    client.Connect("smtp.mail.ru", 587, false);
                    client.Authenticate("valerytihonova@mail.ru", "GhxhsQvvcgkr0jsiJbh7");
                    client.Send(message);
                    client.Disconnect(true);
                }
                catch (Exception ex)
                {
                    // Логирование ошибки
                    Console.WriteLine($"Ошибка при отправке email: {ex.Message}");
                }
            }
        }

        private void AddTaskNotification(int tId)
        {
            string query = @"
        IF NOT EXISTS (SELECT 1 FROM [Уведомления по задачам] WHERE [Id задачи] = @tId)
        BEGIN
            INSERT INTO [Уведомления по задачам] ([Id задачи])
            VALUES (@tId);
        END";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@tId", tId);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private void DeleteTaskNotification(int tId)
        {
            string query = @"
DELETE FROM [Уведомления по задачам]
WHERE [Id задачи] = @tId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@tId", tId);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
