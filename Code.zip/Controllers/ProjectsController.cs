﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using MailKit;
using MimeKit;
using MailKit.Security;
using MailKit.Net.Smtp;
using System.Text;
using Microsoft.AspNetCore.Authorization;

namespace WebAvia.Controllers
{
    [Authorize]
    public class ProjectsController : Controller
    {
        string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var projects = GetProjects();
            return View(projects);
        }

        public IActionResult Index1()
        {
            string login = HttpContext.Session.GetString("Login");
            var projects = GetProjectsForEmployee(login);
            return View(projects);
        }

        public IActionResult IndexForTeamLead()
        {
            string login = HttpContext.Session.GetString("Login");
            var projects = GetProjectsForTeamLead(login);

            // Формируем строку с информацией о проектах, которые были удалены из уведомлений
            string updatedProjectsMessage = CheckAndRemoveProjectNotification(projects);

            // Передаем строку с информацией о проектах в TempData
            TempData["UpdatedProjectsMessage"] = updatedProjectsMessage;

            return View("Index2", projects);
        }

        private string CheckAndRemoveProjectNotification(DataTable projects)
        {
            string updatedProjectsMessage = "";
            string query = @"
SELECT [Id проекта] FROM [Уведомления по проектам]";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Получаем список проектов из таблицы Уведомления по проектам
                SqlCommand selectCommand = new SqlCommand(query, connection);
                SqlDataReader reader = selectCommand.ExecuteReader();
                var notificationProjectIds = new List<int>();

                while (reader.Read())
                {
                    notificationProjectIds.Add(reader.GetInt32(0));
                }

                reader.Close();

                // Проверяем каждый проект из таблицы проектов
                foreach (DataRow project in projects.Rows)
                {
                    int projectId = (int)project["Id проекта"];
                    if (notificationProjectIds.Contains(projectId))
                    {
                        // Удаляем уведомление
                        SqlCommand deleteCommand = new SqlCommand("DELETE FROM [Уведомления по проектам] WHERE [Id проекта] = @projectId", connection);
                        deleteCommand.Parameters.AddWithValue("@projectId", projectId);
                        deleteCommand.ExecuteNonQuery();

                        // Добавляем информацию о проекте в строку
                        updatedProjectsMessage = updatedProjectsMessage + project["Id проекта"].ToString() + ", ";
                    }
                }

                if (!string.IsNullOrEmpty(updatedProjectsMessage))
                {
                    updatedProjectsMessage = updatedProjectsMessage.TrimEnd(',', ' ');
                    updatedProjectsMessage = updatedProjectsMessage + ".";
                }
            }

            return updatedProjectsMessage;
        }

        private DataTable GetProjectsForEmployee(string employeeId)
        {
            DataTable table = new DataTable();
            try
            {
                if (string.IsNullOrEmpty(employeeId))
                {
                    TempData["ErrorMessage"] = "Ошибка: Идентификатор сотрудника не указан.";
                    return table;
                }

                string query = @"
            SELECT DISTINCT p.[Id проекта], p.[Название], p.[Описание], e.[ФИО] AS [Тим лид], p.[Дата начала], p.[Дата завершения], p.[Статус]
            FROM Проекты p
            JOIN Задачи z ON p.[Id проекта] = z.[Id проекта]
            JOIN Сотрудники e ON p.[Id тим лида] = e.[Id сотрудника]
            WHERE z.[Id сотрудника] = @EmployeeId";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.SelectCommand.Parameters.AddWithValue("@EmployeeId", employeeId);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        private DataTable GetProjectsForTeamLead(string teamLeadId)
        {
            DataTable table = new DataTable();
            try
            {
                string query = @"
            SELECT p.[Id проекта], p.[Название], p.[Описание], e.[ФИО] AS [Тим лид], p.[Дата начала], p.[Дата завершения], p.[Статус]
            FROM Проекты p
            JOIN Сотрудники e ON p.[Id тим лида] = e.[Id сотрудника]
            WHERE p.[Id тим лида] = @TeamLeadId";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.SelectCommand.Parameters.AddWithValue("@TeamLeadId", teamLeadId);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        private DataTable GetProjects()
        {
            DataTable table = new DataTable();
            try
            {
                string query = "SELECT * FROM Проекты";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }
        
        [HttpPost]
        public IActionResult UpdateProject(int id_проекта, string columnName, string newValue)
        {
            try
            {
                string query = $"UPDATE Проекты SET [{columnName}] = @newValue WHERE [Id проекта] = @id_проекта";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_проекта", id_проекта);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

                // Отправка уведомления, если изменяется тим лид
                if (columnName.Equals("Id тим лида", StringComparison.OrdinalIgnoreCase))
                {
                    int newTeamLeadId = int.Parse(newValue);
                    SendEmailNotification(newTeamLeadId, "Изменение тим лида", $"Вы были назначены тим лидом проекта с ID {id_проекта}.");

                    // Добавление ID проекта в таблицу Уведомления по проектам
                    AddProjectNotification(id_проекта);
                }

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult DeleteProject(int id_проекта)
        {
            try
            {
                string query = "DELETE FROM Проекты WHERE [Id проекта] = @id_проекта";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_проекта", id_проекта);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

                DeleteProjectNotification(id_проекта);

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult AddProject(string Название, int IdТимЛида)
        {
            try
            {
                int projectId = 0;
                string query = @"
            INSERT INTO Проекты (Название, [Id тим лида])
            VALUES (@Название, @IdТимЛида);
            SET @ProjectId = SCOPE_IDENTITY();";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Название", Название);
                    command.Parameters.AddWithValue("@IdТимЛида", IdТимЛида);

                    // Добавление выходного параметра
                    SqlParameter outputParam = new SqlParameter("@ProjectId", SqlDbType.Int)
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(outputParam);

                    connection.Open();
                    command.ExecuteNonQuery();

                    // Получение значения выходного параметра
                    projectId = (int)outputParam.Value;
                }

                // Отправка уведомления
                SendEmailNotification(IdТимЛида, "Новый проект", $"Вы были назначены тим лидом нового проекта с ID {projectId}.");

                // Добавление ID проекта в таблицу Уведомления по проектам
                AddProjectNotification(projectId);

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        public JsonResult GetTeamLeads()
        {
            var teamLeads = new List<object>();
            string query = "SELECT [Id сотрудника], [ФИО] FROM Сотрудники WHERE [Id роли] = 2";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        teamLeads.Add(new { Id = reader["Id сотрудника"], Name = reader["ФИО"] });
                    }
                }
            }

            return Json(teamLeads);
        }

        private string GetEmployeeEmail(int employeeId)
        {
            string email = string.Empty;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Email FROM Сотрудники WHERE [Id сотрудника] = @EmployeeId";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@EmployeeId", employeeId);
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            email = reader["Email"].ToString();
                        }
                    }
                }
            }

            return email;
        }

        private void SendEmailNotification(int employeeId, string subject, string body)
        {
            string recipientEmail = GetEmployeeEmail(employeeId);

            var message = new MimeMessage();
            message.From.Add(new MailboxAddress("Валерия", "valerytihonova@mail.ru"));
            message.To.Add(new MailboxAddress("", recipientEmail));
            message.Subject = subject;
            message.Body = new TextPart("plain") { Text = body };

            using (var client = new MailKit.Net.Smtp.SmtpClient(new ProtocolLogger("smtp.log")))
            {
                try
                {
                    client.Connect("smtp.mail.ru", 587, false);
                    client.Authenticate("valerytihonova@mail.ru", "GhxhsQvvcgkr0jsiJbh7");
                    client.Send(message);
                    client.Disconnect(true);
                }
                catch (Exception ex)
                {
                    // Логирование ошибки
                    Console.WriteLine($"Ошибка при отправке email: {ex.Message}");
                }
            }
        }

        private void AddProjectNotification(int projectId)
        {
            string query = @"
        IF NOT EXISTS (SELECT 1 FROM [Уведомления по проектам] WHERE [Id проекта] = @projectId)
        BEGIN
            INSERT INTO [Уведомления по проектам] ([Id проекта])
            VALUES (@projectId);
        END";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@projectId", projectId);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        private void DeleteProjectNotification(int projectId)
        {
            string query = @"
DELETE FROM [Уведомления по проектам]
WHERE [Id проекта] = @projectId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@projectId", projectId);
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}
