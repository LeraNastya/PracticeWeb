﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using BCrypt.Net;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using System.Threading.Tasks;

namespace WebAvia.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(string login, string password)
        {
            string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

            using (SqlConnection MyConnection = new SqlConnection(connectionString))
            {
                try
                {
                    await MyConnection.OpenAsync();

                    string query = "SELECT [Id сотрудника], [Пароль], [Id роли] FROM Сотрудники WHERE [Id сотрудника] = @Login";

                    using (SqlCommand cmd = new SqlCommand(query, MyConnection))
                    {
                        cmd.Parameters.AddWithValue("@Login", login);

                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                if (reader["Id сотрудника"] == DBNull.Value || reader["Пароль"] == DBNull.Value || reader["Id роли"] == DBNull.Value)
                                {
                                    TempData["ErrorMessage"] = "Отсутствуют необходимые данные в базе.";
                                    return View();
                                }

                                string log = reader["Id сотрудника"].ToString().TrimEnd();
                                string storedPassword = reader["Пароль"].ToString().TrimEnd();
                                int roleId;
                                if (int.TryParse(reader["Id роли"].ToString(), out roleId))
                                {
                                    // Проверяем, является ли пароль хешированным с использованием BCrypt
                                    if (storedPassword.StartsWith("$2a$") || storedPassword.StartsWith("$2b$") || storedPassword.StartsWith("$2y$"))
                                    {
                                        // Пароль уже хеширован с использованием BCrypt
                                        if (BCrypt.Net.BCrypt.Verify(password, storedPassword))
                                        {
                                            // Сохраняем логин и роль в сессии
                                            HttpContext.Session.SetString("Login", login);
                                            HttpContext.Session.SetString("IsAuthenticated", "true");

                                            var claims = new[]
                                            {
                                                new Claim(ClaimTypes.Name, login)
                                            };

                                            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                                            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));

                                            // Перенаправляем в зависимости от роли
                                            return RedirectToRoleSpecificAction(roleId);
                                        }
                                        else
                                        {
                                            TempData["ErrorMessage"] = "Неверный пароль.";
                                            return View();
                                        }
                                    }
                                    else
                                    {
                                        // Пароль не хеширован с использованием BCrypt, перехешируем его
                                        string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);
                                        UpdateHashedPassword(connectionString, login, hashedPassword);

                                        // Сохраняем логин и роль в сессии
                                        HttpContext.Session.SetString("Login", login);
                                        HttpContext.Session.SetString("IsAuthenticated", "true");

                                        var claims = new[]
                                        {
                                            new Claim(ClaimTypes.Name, login)
                                        };

                                        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                                        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));

                                        // Перенаправляем в зависимости от роли
                                        return RedirectToRoleSpecificAction(roleId);
                                    }
                                }
                                else
                                {
                                    TempData["ErrorMessage"] = "Ошибка при получении идентификатора роли.";
                                    return View();
                                }
                            }
                            else
                            {
                                TempData["ErrorMessage"] = "Пользователь не найден.";
                                return View();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                    return View();
                }
            }
        }

        private static void UpdateHashedPassword(string connectionString, string login, string hashedPassword)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string updateQuery = "UPDATE Сотрудники SET [Пароль] = @HashedPassword WHERE [Id сотрудника] = @Login";

                using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@HashedPassword", hashedPassword);
                    cmd.Parameters.AddWithValue("@Login", login);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private IActionResult RedirectToRoleSpecificAction(int roleId)
        {
            switch (roleId)
            {
                case 1:
                    HttpContext.Session.SetString("Role", "Role1");
                    return RedirectToAction("Index", "Projects");
                case 2:
                    HttpContext.Session.SetString("Role", "Role2");
                    return RedirectToAction("IndexForTeamLead", "Projects");
                case 3:
                    HttpContext.Session.SetString("Role", "Role3");
                    return RedirectToAction("Index1", "Projects");
                default:
                    TempData["ErrorMessage"] = "Неизвестная роль.";
                    return View();
            }
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("Login");
            HttpContext.Session.Remove("IsAuthenticated");
            HttpContext.Session.Remove("Role");
            return RedirectToAction("Index", "Login");
        }
    }
}
