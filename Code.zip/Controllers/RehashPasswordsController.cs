﻿using BCrypt.Net;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace WebAvia.Controllers
{
    public class RehashPasswordsController : Controller
    {
        public IActionResult Index()
        {
            string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

            using (SqlConnection MyConnection = new SqlConnection(connectionString))
            {
                try
                {
                    MyConnection.Open();

                    // SQL-запрос для получения всех сотрудников
                    string query = "SELECT [Id сотрудника], Пароль FROM Сотрудники";

                    using (SqlCommand cmd = new SqlCommand(query, MyConnection))
                    {
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                if (reader["Пароль"] != DBNull.Value)
                                {
                                    string login = reader["Id сотрудника"].ToString().TrimEnd();
                                    string oldHashedPassword = reader["Пароль"].ToString().TrimEnd();

                                    // Перехешируем пароль
                                    string newHashedPassword = BCrypt.Net.BCrypt.HashPassword(oldHashedPassword);

                                    // Обновляем пароль в базе данных
                                    string updateQuery = "UPDATE Сотрудники SET Пароль = @NewHashedPassword WHERE [Id сотрудника] = @Login";
                                    using (SqlCommand updateCmd = new SqlCommand(updateQuery, MyConnection))
                                    {
                                        updateCmd.Parameters.AddWithValue("@NewHashedPassword", newHashedPassword);
                                        updateCmd.Parameters.AddWithValue("@Login", login);
                                        updateCmd.ExecuteNonQuery();
                                    }
                                }
                            }
                        }
                    }

                    return Content("Пароли успешно перехешированы.");
                }
                catch (Exception ex)
                {
                    return Content("Ошибка: " + ex.Message);
                }
            }
        }
    }
}
