﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using BCrypt.Net;
using Microsoft.AspNetCore.Authorization;

namespace WebAvia.Controllers
{
    [Authorize]
    public class EmployeesController : Controller
    {
        string connectionString = "Data Source=WIN-099PT3P6DD9;Initial Catalog=AviaFactory;Integrated Security=True;Encrypt=False";

        public IActionResult Index()
        {
            var employees = GetEmployees();
            return View(employees);
        }

        public IActionResult Index1()
        {
            var employees = GetEmployeesForIndex1();
            return View(employees);
        }

        private DataTable GetEmployees()
        {
            DataTable table = new DataTable();
            try
            {
                string query = @"
        SELECT s.[Id сотрудника], s.ФИО, s.Телефон, s.Email, s.[Id должности], s.[Id роли], s.Пароль, s.[Дата найма], COUNT(z.[Id задачи]) AS Задачи
        FROM Сотрудники s
        LEFT JOIN Задачи z ON s.[Id сотрудника] = z.[Id сотрудника] AND z.Статус = 0
        GROUP BY s.[Id сотрудника], s.ФИО, s.Телефон, s.Email, s.[Id должности], s.[Id роли], s.Пароль, s.[Дата найма]";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        private DataTable GetEmployeesForIndex1()
        {
            DataTable table = new DataTable();
            try
            {
                string query = @"
        SELECT s.[Id сотрудника], s.ФИО, d.Название AS Должность, s.Телефон, s.Email, COUNT(z.[Id задачи]) AS Задачи
        FROM Сотрудники s
        LEFT JOIN Задачи z ON s.[Id сотрудника] = z.[Id сотрудника] AND z.Статус = 0
        LEFT JOIN Должности d ON s.[Id должности] = d.[Id должности]
        GROUP BY s.[Id сотрудника], s.ФИО, d.Название, s.Телефон, s.Email
        ORDER BY s.[Id сотрудника]";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    dataAdapter.Fill(table);
                }
                return table;
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return table;
            }
        }

        [HttpPost]
        public IActionResult UpdateEmployee(int id_сотрудника, string columnName, string newValue)
        {
            try
            {
                if (columnName == "Пароль" && newValue != "*****")
                {
                    newValue = BCrypt.Net.BCrypt.HashPassword(newValue);
                }

                string query = $"UPDATE Сотрудники SET [{columnName}] = @newValue WHERE [Id сотрудника] = @id_сотрудника";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@newValue", newValue);
                    command.Parameters.AddWithValue("@id_сотрудника", id_сотрудника);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult DeleteEmployee(int id_сотрудника)
        {
            try
            {
                string query = "DELETE FROM Сотрудники WHERE [Id сотрудника] = @id_сотрудника";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@id_сотрудника", id_сотрудника);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false });
            }
        }

        [HttpPost]
        public IActionResult AddEmployee(string Пароль, string ФИО, int IdРоли, int IdДолжности)
        {
            try
            {
                Пароль = BCrypt.Net.BCrypt.HashPassword(Пароль);

                string query = "INSERT INTO Сотрудники (Пароль, ФИО, [Id роли], [Id должности]) VALUES (@Пароль, @ФИО, @IdРоли, @IdДолжности)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Пароль", Пароль);
                    command.Parameters.AddWithValue("@ФИО", ФИО);
                    command.Parameters.AddWithValue("@IdРоли", IdРоли);
                    command.Parameters.AddWithValue("@IdДолжности", IdДолжности);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Ошибка: " + ex.Message;
                return Json(new { success = false });
            }
        }

        public JsonResult GetRoles()
        {
            var roles = new List<object>();
            string query = "SELECT [Id роли], [Название] FROM Роли";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        roles.Add(new { Id = reader["Id роли"], Name = reader["Название"] });
                    }
                }
            }

            return Json(roles);
        }

        public JsonResult GetPositions()
        {
            var positions = new List<object>();
            string query = "SELECT [Id должности], [Название] FROM Должности";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        positions.Add(new { Id = reader["Id должности"], Name = reader["Название"] });
                    }
                }
            }

            return Json(positions);
        }
    }
}
